package com.devco.viajes.excepciones;

public class ParametrosIncorrectos extends Exception {

}
