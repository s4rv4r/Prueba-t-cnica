import { ReservaViaje } from './reserva-viaje';

describe('ReservaViaje', () => {
  // it('should create an instance', () => {
  //   expect(new ReservaViaje('1','colombia','peru','2019-01-01','2019-02-01')).toBeTruthy();
  // });
});
