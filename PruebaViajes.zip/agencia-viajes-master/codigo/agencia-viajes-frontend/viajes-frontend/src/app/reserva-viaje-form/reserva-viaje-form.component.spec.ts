import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservaViajeFormComponent } from './reserva-viaje-form.component';

describe('ReservaViajeFormComponent', () => {
  let component: ReservaViajeFormComponent;
  let fixture: ComponentFixture<ReservaViajeFormComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [ ReservaViajeFormComponent ]
  //   })
  //   .compileComponents();
  // }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(ReservaViajeFormComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
