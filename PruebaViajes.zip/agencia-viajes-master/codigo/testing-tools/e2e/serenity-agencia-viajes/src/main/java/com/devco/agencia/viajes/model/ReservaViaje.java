package com.devco.agencia.viajes.model;

public class ReservaViaje {
    private String origen;
    private String destino;
    private String fechaIda;
    private String fechaRegreso;
}
